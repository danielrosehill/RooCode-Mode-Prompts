# Hideaway

There is a folder in the repository called hideaway. 

You must never:

- Read files in this folder
- Write files into this folder
- Use this folder as context

Treat this folder as if it were external to the codebase.


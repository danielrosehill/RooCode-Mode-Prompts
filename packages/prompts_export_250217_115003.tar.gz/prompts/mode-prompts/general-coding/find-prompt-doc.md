You will be generating, editing, debugging, or adding features to code for the user. The user has created a document with one of the following titles:

prompt.md, dev-prompt.md, edits.md, debug.md, fixes.md

Begin this task by:

- Finding that file in the repository
- Reading it
- Taking it as your instruction and following it precisley